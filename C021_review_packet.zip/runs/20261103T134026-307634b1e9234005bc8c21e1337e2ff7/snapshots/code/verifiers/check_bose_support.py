"""Original separate triple-sum verification; does not import support producer."""
import json
import os
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from verifiers.check_set import check_set

cfg=json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
cap=int(os.environ["MATH_MAX_STATES"])
pcap=int(os.environ["MATH_MAX_PERIOD_ENUMERATION"])
wcap=int(os.environ["MATH_MAX_PARALLEL_WORKERS"])
assert pcap>=1 and wcap>=1
states=0
def tick(n=1):
    global states
    if states+n>cap:
        raise RuntimeError("state cap reached")
    states+=n

result={"status":"RUNNING","tables":[],"truncated":False,"caps":{"states":cap,"periods":pcap,"workers":wcap},"periods":0,"workers":1}
try:
    data=json.loads(Path(cfg["canonical"]).read_text(encoding="utf-8"))
    assert data["status"]=="PASS" and not data["truncated"]
    for row in data["cases"]:
        B=row["B"]
        p=row["p"]
        triples=Counter()
        for a in B:
            for b in B:
                for c in B:
                    tick()
                    triples[a+b+c]+=1
        counts=Counter()
        for t,n in triples.items():
            for d in B:
                tick()
                counts[t-d]+=n
        recorded={h:n for h,n,w in row["support"]}
        assert counts==recorded and sum(counts.values())==p**4
        for h,n,w in row["support"]:
            tick()
            assert n>0 and len(w)==4 and all(x in B for x in w)
            assert sum(w[:3])-w[3]==h
        lo,hi=row["full_integer_range"]
        assert (lo,hi)==(3*min(B)-max(B),3*max(B)-min(B))
        for h in range(lo,hi+1):
            tick()
            assert counts[h]==recorded.get(h,0)
        first,upper=row["S_scan_range"]
        missing=[S for S in range(first,upper+1) if counts[S]==0]
        assert missing==row["all_missing_S_in_scan"] and missing[0]==row["S"]
        assert row["prefix_witnesses"]==[[h,next(w for x,n,w in row["support"] if x==h)] for h in range(first,row["S"])]
        N=row["S"]-2*min(B)+1
        A=sorted([b+1-min(B) for b in B]+[row["S"]-b+1-min(B) for b in B])
        tick(2*N+len(A)*(len(A)+1)//2)
        checked=check_set(N,A)
        assert checked==row["independent_sum_checker"] and checked["admissible"]
        M=p*p-1
        modulo=Counter()
        for h,n in counts.items():
            tick()
            modulo[h%M]+=n
        assert [modulo[r] for r in range(M)]==row["modular_counts"]
        S=row["S"]
        r=S%M
        layers={str((h-r)//M):n for h,n in sorted(counts.items()) if h%M==r}
        assert str((S-r)//M) not in layers
        result["tables"].append({"p":p,"S":S,"N":N,"support_size":len(counts),
            "bounded_zeros_verified":hi-lo+1-len(counts),"first_hole_residue":r,
            "first_hole_carry":(S-r)//M,"other_lift_counts_at_that_residue":layers,
            "total_modular_count_at_hole_residue":modulo[r]})
    result["status"]="PASS"
except RuntimeError as error:
    result.update(status="LIMIT_REACHED",truncated=True,error=str(error))
finally:
    result["states"]=states
    out=Path(os.environ["MATH_RUN_DIR"])/"outputs"/"support_verification.json"
    out.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2))
if result["status"]!="PASS":
    raise SystemExit(2)
