"""Exact unordered-sum verifier, independent of incremental search decisions.

Original project code (2026-11-03); Python standard library only.
CLI: python verifiers/check_set.py N '[1,2,3]' [--output path]
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def check_set(N: int, elements: list[int]) -> dict:
    if type(N) is not int or N <= 0:
        raise ValueError("N must be a positive integer")
    if not isinstance(elements, (list, tuple)):
        raise ValueError("elements must be a finite list or tuple")
    if any(type(a) is not int for a in elements):
        raise ValueError("every element must be an integer (bool excluded)")
    if any(a < 1 or a > N for a in elements):
        raise ValueError("elements must lie in [1,N]")
    if len(set(elements)) != len(elements):
        raise ValueError("elements must be distinct")
    A = sorted(elements)
    # Full support [2,2N], including explicit zeros. Nested index traversal
    # visits exactly k(k+1)/2 pairs, with every diagonal included once.
    representations = {s: [] for s in range(2, 2*N+1)}
    for i in range(len(A)):
        for j in range(i, len(A)):
            representations[A[i]+A[j]].append([A[i], A[j]])
    exceptional = {s: pairs for s, pairs in representations.items() if len(pairs)>1}
    return {
        "N": N, "elements": A, "size": len(A),
        "pair_count": sum(map(len, representations.values())),
        "representation_function": {str(s): len(pairs) for s, pairs in representations.items()},
        "representations": {str(s): pairs for s, pairs in representations.items()},
        "exceptional_sums": {str(s): pairs for s, pairs in exceptional.items()},
        "admissible": len(exceptional)<=1,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("N", type=int)
    parser.add_argument("elements", help="JSON array of candidate integers")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        result = check_set(args.N, json.loads(args.elements))
    except (ValueError, TypeError) as error:
        parser.error(str(error))
    data = json.dumps(result, indent=2)+"\n"
    if args.output:
        args.output.write_text(data, encoding="utf-8")
    print(data, end="")
    return 0 if result["admissible"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
