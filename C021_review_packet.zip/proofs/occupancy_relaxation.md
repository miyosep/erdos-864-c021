# E864-C008/C009: normalization, split occupancy, and a marginal obstruction

This note studies the fixed-saving core lemma; it does not prove that lemma.
All claims are self-reviewed only. Dense Sidon equidistribution is known, so its
elementary derivation below is a reproduction, not a novelty claim.

## Normalize a symmetric core by its own span

Let C be a nonempty finite integer set invariant under c->S-c. If m=min C and
M=max C, symmetry forces S=m+M. Translating by 1-m gives a symmetric subset
C' of [1,N'], where N'=M-m+1 and the new sum is S'=N'+1. It contains 1,N'.
Admissibility and cardinality are translation invariant: every pair sum is
translated by 2(1-m). This is a normalization of C's own span, not an assertion
that an arbitrary A subset [1,N] has exceptional sum N+1. N'<=N if C fits [1,N].
The center is a separate optional singleton and changes cardinality by at most 1.
For N'>=2, write C'=B union (S'-B), optionally with S'/2, where
B subset [1,floor(N'/2)]. B is Sidon and has no b1+b2+b3-b4=S' by C002.
If C' has only one element, handle it directly rather than introduce empty span.

Translating instead to min C=0 also preserves the proof of C002: for
B0 subset [0,floor((D-1)/2)], the low sums are still <D, high sums >D, and the
parts disjoint. The same equation with D replaces S. This extension follows
by translating B0 to B0+1, S to D+2 and applying C002, including its center
condition. There is no new hypothesis about positivity hidden in normalization.

## A finite split-translate inequality for every Sidon base

Let B subset [1,L] be Sidon, b=|B|, 1<=x<L, and j=|B intersect [1,x]|.
For every h>=1 put a=x+h-1, d=L-x+h-1 and T=a+d=L+2h-2. Then

    j^2/a + (b-j)^2/d <= 1+(b-1)/h.                 (6)

To prove this, split B into B1,B2 at x and let g_i(y) count the elements of
Bi with 0<=y-b'<h. Their supports have at most a,d integer positions. Cauchy
gives sum g1^2>=h^2*j^2/a and sum g2^2>=h^2*(b-j)^2/d. For g=g1+g2,
nonnegative cross terms give sum g^2>=sum g1^2+sum g2^2. Since every positive
difference of B is unique, the overlap identity gives sum g^2<=hb+h(h-1).
Division by h^2 proves (6). This includes empty and singleton B.

For b>0 the exact algebraic identity

    j^2/a+(b-j)^2/d=b^2/T + T/(a*d)*(j-b*a/T)^2

implies

    |j/b-a/T|^2 <= a*d/(T*b^2)*(1+(b-1)/h-b^2/T). (7)

All denominators are positive, and the last bracket is nonnegative because
the preceding proved inequalities imply it. No square roots of negative
computed error terms should be used.

If L->infinity and b/sqrt(L)->1, take h=ceil(L^(3/4)). Then T/L->1,
(b-1)/h->0, and b^2/T->1. The prefactor a*d/(T*b^2)<=T/(4b^2) stays bounded,
uniformly in x. Thus j/b-x/L->0 uniformly. The normalized empirical measures
of B converge to the uniform probability measure on [0,1]. This conclusion
requires density near the Sidon upper constant, not merely order sqrt(L).

## The hypothetical endpoint for symmetric admissible cores

Suppose, only hypothetically, a sequence of normalized symmetric admissible cores
C' subset [1,N'] has |C'|/sqrt(N')->sqrt(2). Let L=floor(N'/2), S'=N'+1,
and B the lower half. The center is negligible and |B|/sqrt(L)->1. Therefore
the preceding uniform distribution applies to B/L. Also S'/L->2.

Let P=B+B count distinct unordered sums; let D_+=(B-B) intersect positive
integers. Because B is Sidon, all P representations and all positive-difference
representations are unique. The measures

    (1/L) sum_{p in P} delta_(p/L),
    (1/L) sum_{d in D_+} delta_(d/L)

converge weakly to densities

    p(t)=t/2       for 0<t<1,
         (2-t)/2   for 1<t<2,
    d(t)=1-t       for 0<t<1,

and zero elsewhere. Proof: the normalized Cartesian-pair empirical measure
converges to uniform measure on the unit square. For sums divide the ordered
pair count by two; the b diagonal pairs contribute o(L). For positive differences
restrict the square to its upper triangle; the diagonal again has zero limiting
mass. Indicator tests on interval boundaries are valid since these limiting
sum/difference distributions have no atoms. This also proves convergence for
all fixed intervals, not merely their total masses.

C002 forbids P intersect (S'-D_+). The second family's limiting density is
q(t)=t-1 for 1<t<2, zero elsewhere. Consequently the combined density is

    p(t)+q(t)=t/2 for 0<t<2,

with maximum 1 at the right endpoint. In particular for every interval I,
integral_I(p+q)<=length(I). These are exactly the limiting capacity inequalities
obtained by placing the two disjoint integer sum families into intervals.
They hold at the hypothetical sqrt(2) endpoint.

This proves compatibility of this PARTICULAR marginal relaxation, not existence
of any sequence of actual admissible cores at that endpoint. Independence of
the two families is neither assumed nor concluded. Their correlation at the
same individual integers is information that these interval marginals discard.
The full symmetric-core lemma is still OPEN after this analysis.
