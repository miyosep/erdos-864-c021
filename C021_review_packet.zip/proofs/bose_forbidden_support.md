# Cycle 3: exact forbidden support of degree-two Bose-Chowla bases

The arguments were proposed before computation and subsequently completed and
self-reviewed. Final scope, finite coverage and claim statuses are recorded
in claims.json, the cycle report and review_cycle3_bose_support.md.
This is one resumed cycle of e864_20261103_02, not a new session or loop.

## Reflection reduction and an exact integer gap parameter (C012)

For any finite nonempty integer Sidon base B, set m=min B, v=max B, D=v-m,
and H={b1+b2+b3-b4:bi in B}, with repetition. For each S>2v the two parts
B and S-B are disjoint. Translate their union by 1-m. Its minimum is 1,
maximum N=S-2m+1, and size 2|B|. Its reflection sum after translation is
S'=S+2(1-m)=N+1. The translated lower base is B'=B+1-m subset
[1,floor((S'-1)/2)]. Sidon uniqueness is invariant under translation, and
3B'-B'=H+2(1-m). C002 therefore proves admissibility exactly when S not in H.
All diagonals are included. A possible central singleton is NOT added here.
The reduction works for a base lifted with 0 as well, because B' is positive.

Every H value is in [3m-v,3v-m], and both endpoints are attained. Thus the
least permitted S exists in [2v+1,3v-m+1]. Its minimality is only within this
fixed-base, two-disjoint-reflected-parts construction, not among all sets.

Put X=v-B, Y=B-m, and Z=X+X+X+Y. Then H=3v-m-Z exactly, as integer sets.
If D>0 define

  d=max({-1} union ({0,...,D-1} minus Z)).

Scanning S upwards is equivalent to scanning z downwards from D-1 to -1;
z=-1 is absent since Z is nonnegative. Consequently

  S_min=3v-m-d,       N_min=3D+1-d.                (13)

For a singleton D=0, use d=-1; the same formulas give S_min=2m+1,N=2.
For |B|>=2 let g be the smaller of its first and last adjacent gaps. If g>=2,
then Z contains 0 but not 1,...,g-1, so d>=g-1 and N_min<=3D+2-g. If g=1
this argument supplies no gap; do not assert that 0 is absent from Z.

## Modular mechanism for every primitive element (C013)

Let K be F_(p^2), theta primitive, M=p^2-1, and C=theta+F_p in K^*. Its
logarithms B modulo M are the standard Bose-Chowla set (S8, Theorem 1).
Write J=F_p^* as a subgroup of K^*. For any gamma in K^*, the number of
ordered ratios (theta+u)/(theta+v)=gamma is

  p if gamma=1; 0 if gamma in J minus {1}; 1 if gamma not in J.       (14)

Proof: the first two cases follow by comparing the theta coefficient. In the
last case write gamma=a+b*theta with b!=0 and theta^2=T*theta-U. Comparing
theta coefficients in theta+u=gamma*(theta+v) determines v uniquely; the
constant coefficient then determines u. All resulting factors are nonzero.

The image of C in K^*/J is a bijection onto all its p nonidentity cosets:
two C elements in one coset have a ratio in J and hence coincide by (14);
none is in J. There are p+1 cosets. It follows that the number of ordered
pairs (c1,c2) in C^2 with c1*c2 in gamma*J equals p when gamma in J and p-1
otherwise. Indeed, in a group of order p+1 the product of two nonidentity
elements has p factorizations if the target is the identity, p-1 otherwise.

Let R_2(r) count ordered b1+b2=r modulo M and Q(r) count ordered
b1+b2+b3-b4=r modulo M. Convolving (14) with the pair-product counts gives

  Q(r)=p^2-p+1_{r not in J_log}+p*R_2(r),           (15)
  J_log={0,p+1,2(p+1),...,(p-2)(p+1)} modulo M.

In particular Q(r)>=p^2-p>0 for every residue and every prime p>=2. No
reflection parameter can be excluded by a missing residue of H modulo M.
This is a scoped obstruction to a modular-hole mechanism, not to integer holes.
The relative-difference identity is classical structure; the displayed count
is its elementary consequence. No novelty established by the limited search.

For any chosen integer representatives, with q(h) their exact ordered count,

  Q(r)=sum_{j in Z} q(r+jM),   0<=r<M.             (16)

The sum is finite. For representatives in [0,M-1] the possible carry indices
are -1,0,1,2; shifting every representative by 1 can move the endpoint layers.
For a general lifted interval use [3m-v,3v-m] to determine the actual indices.
Positive modular counts do not imply q(S)>0 for any particular lift S.

## Primitive elements, cyclic cuts, and what is invariant (C014)

Fix theta and let eta=theta^k, gcd(k,M)=1. Write eta=a+b*theta over F_p;
b!=0 since eta is primitive and cannot lie in F_p. Let ell=log_theta(b).
Then eta+F_p=b*(theta+F_p), and hence

  B_eta = k^(-1)*(B_theta+ell) modulo M.           (17)

Thus changing the standard primitive element includes both a unit multiplier
and a translation; it is not just relabelling the old logarithms. A cut c,
lifted positively, is B_(eta,c)={((u-c) mod M)+1:u in B_eta}. Its residue
translation is t=1-c; Q shifts by 2t. Formula (15) becomes

  Q_(eta,c)(r)=p^2-p+1_{r-2t not in J_log}+p*R_(eta,c),2(r).

Integer supports, first permitted S and N need not be invariant. Uniform
obstruction claims below apply only where proved, not from one canonical cut.

## A uniform obstruction to shortening the base or using a macroscopic edge gap

For ANY sequence of standard primitive choices and cyclic cuts as p grows,
the positive lifts are integer Sidon sets of size p in [1,M], and p/sqrt(M)->1.
C008's finite inequality gives uniform macroscopic equidistribution independent
of those choices. Therefore m/M->0, v/M->1, and D/M->1 uniformly. For example,
for any fixed delta>0, the first and last intervals of length delta*M each
contain asymptotically delta*p elements; thus they contain two elements for
large p. Both endpoint adjacent gaps divided by M consequently tend to zero.
The same finite bound makes these conclusions uniform over choices/cuts.

For completeness, a quantitative version follows without a new literature
premise. In C008's (7) take L=M, b=p, h=ceil(M^(3/4)) and T=M+2h-2.
The bracket is at most p/h+2h/M<=6M^(-1/4), and its prefactor is at most
T/(4p^2)<=5/4 (M>=3). Thus |j/p-a/T|<=3M^(-1/8). Also
|a/T-x/M|<=(h-1)/T<=2M^(-1/4). The CDF discrepancy is at most
5M^(-1/8), uniformly in all bases and cuts. The first and last intervals of
length ceil(6M^(7/8)) therefore each contain at least two elements for all
sufficiently large p. It follows uniformly that

  D=p^2+O(p^(7/4)),      endpoint gaps=O(p^(7/4)),
  N_min=3p^2-d+O(p^(7/4)).                         (18)

The constants are absolute; only asymptotic statements for unbounded p are
needed here. In particular a fixed improvement in N along an infinite sequence
is equivalent to a positive limsup of d/p^2 along that sequence, with a smaller
fixed constant if needed to absorb the error. This is a reduction of the
unresolved integer question, not a proof that the limsup is positive or zero.

Consequences: reducing the base's own span, or the GUARANTEED single-edge-gap
saving in (13), cannot by itself yield a fixed fractional saving in p^2. This
does NOT prove d=o(p^2): Z=3X+Y may have larger internal holes even though X,Y
are macroscopically uniform. For a fixed choice sequence, (13) and D/p^2->1
show that a fixed asymptotic improvement requires d/p^2 bounded below by a
positive constant along an infinite subsequence (and such a bound suffices).
Controlling those carry-resolved integer holes is the unresolved step.

## Literature checked before numerical jobs

Retained S8 (Nathanson, Theorem 1) covers the construction, already reproduced
in C007. A newly retained primary Cilleruelo preprint, arXiv:1003.3576v2,
printed pp.1-5, was visually read for finite-group Sidon counting and overlap.
It gives related finite-field examples/counting, not an integer-lift theorem
for the present H. The search service returned 503 and a requested Martin-
O'Bryant v1 PDF returned 500; neither failure establishes novelty. Formulae
(14)-(17) have self-contained proofs here. No external code imported/executed.

## Completed finite findings (C015)

Canonical bases p=2,3,5,7,11,17,23,31 were read from the old retained input;
its original SHA-256 was checked before enumeration. Complete ordered H counts
and one quadruple for every supported integer were retained. All zeros inside
the declared integer range were recomputed by a separate ordered-triples-minus-
base implementation. Candidate decisions use the pre-existing independent
unordered-sum checker. All checks passed; same-model checking is self-review.

| p | min B | max B | S_min | N_min | d | edge gap g |
|---|---|---|---|---|---|---|
|2|1|2|6|5|-1|1|
|3|1|7|16|15|4|1|
|5|1|17|40|39|10|2|
|7|1|31|85|84|7|4|
|11|1|112|287|286|48|5|
|17|1|254|546|545|215|3|
|23|1|438|1185|1184|128|3|
|31|1|914|2388|2387|353|13|

For p=31 the first missing integer has residue 468 modulo 960 and carry 2.
At the same residue, the other carry layers -1,0,1 have ordered counts
25,390,547 respectively. Their total is 962, as predicted by (15), while the
requested lift has count zero. This explicitly demonstrates why modular
positivity is insufficient to certify an integer collision.

Full primitive/cut grids: p=2 has 6 cases and N range [5,6]; p=3 has 32 cases
and [11,19]; p=5 has 192 cases and [35,59]; p=7 has 768 cases and [75,132].
There are 998 cases total, all with complete support enumeration and a separate
candidate sum check. The p=7 best case is primitive exponent k=19, cut c=11,
B={19,21,25,26,36,39,48}, S=112, N=75. The p=5 best uses k=7,c=3,N=35;
the original primitive choice's best cut gives N=39. Therefore neither changing
primitive elements nor changing cuts can be dismissed as finite invariances.
No grid was run for p>7, and no new primes beyond 31 were computed.

Canonical run: 20261103T133908-5dd653ea34274d58b3398317a77bc0b7,
710137 states. Choice/cut run: 20261103T134024-8f543cb7000c4c7397ed173d86854982,
1754703 states and 2079 period elements. Separate verifier:
20261103T134026-307634b1e9234005bc8c21e1337e2ff7, 174895 states.
All completed, one worker, no truncation, supplied caps unchanged.

## Evaluation and recommendation

A: no infinite fixed-epsilon saving established. The finite gains and the
nonmonotone d/p^2 values are exploratory evidence only. They are not an
asymptotic counterexample, a rate estimate, or evidence that one cut is universal.

B: two precise mechanisms are ruled out uniformly over primitive choices/cuts:
missing residues modulo p^2-1, and macroscopic span/edge-gap shortening. These
obstructions do NOT rule out macroscopic holes of Z=3(v-B)+(B-m), hence do not
rule out the full degree-two family. Its feasibility remains UNKNOWN.

Recommendation: MODIFY this direction. Retain the family only with a concrete
carry-resolved argument about holes of Z below D; do not seek a missing residue
or infer a fixed saving from a short finite base. The exact modular count can
serve as a conservation identity, but a proof must distribute it among integer
carry layers. Merely extending the prime table would not resolve that step.
No significant novel asymptotic result is claimed; underlying Bose-Chowla and
equidistribution facts are reproduced, and novelty of the derived reductions
has not been established. Stop after this cycle and remain paused.
