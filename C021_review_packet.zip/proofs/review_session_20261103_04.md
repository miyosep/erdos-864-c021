# Self-review, 2026-11-03 UTC

Same author/model, direct algebra and adversarial case review. No independent
or formal check, no numerical evidence used.

* C021: solving for c cancels z-bar(z) only on retained rows/columns.
  Substitution gives z L(c)-bar(z L(c))=theta-bar(theta), as required for e.
  The exceptional condition k real cannot hold on a full affine row family:
  a direction coincidence forces gamma in F_p, and then theta is nonreal.
  The w-real condition is genuinely quadratic even for gamma in F_p.
* Checked the sign in polynomial evaluation: T+b at -w gives b-w and
  at -r gives b-r. Distinct quadratic factors follow from exclusion of
  both conjugates of -theta from w. Full order prevents nonzero exponents
  modulo M from defining a principal local character; conjugation of an
  evaluation point does not identify two distinct factors. S11 (3.33)
  applies even when some local components are trivial.
* Removing rows takes O(1) out of a one-variable sum for pure first modes.
  For mixed modes only retained rows are ever counted. Singular witnesses
  could have large fibers, but the lower bound uses only the parametrized
  subset and does not subtract an estimated singular contribution.
* A cut translates all three tested log coordinates on the torus; it
  changes the field target exponent by -2t. The integer conclusion uses
  a strict interior box so neither the residue zero convention nor a
  moving target at an integer multiple of M produces a boundary error.
  The p=31 zero at a specific lift in C015 is compatible with an eventual
  interior statement having no effective threshold. No endpoint uniformity
  beyond compact subsets is asserted.
* C016's recorded question corresponds to a positive limsup, so the
  universal little-o result answers it negatively. The previous finite
  observations remain valid on their stated scope. The general symmetric
  claim C011 is outside the field parametrization.
* C022: after fixing any one positive slot, fixing the negative slot leaves
  a *sum* problem, avoiding an exceptional zero difference of multiplicity p.
  The two-solution cap is for ordered modular pairs, including diagonals.
  The union bound over slots is valid with repeated coordinates. Both
  macroscopic endpoints of B' persist by C008. For y=3-delta the four
  deficits (including the fourth, low coordinate itself) sum to delta in
  the limit. This gives volume delta³/6; using the elementary bound on
  each slot incidence produces delta²/48, with no assertion of sharpness.
