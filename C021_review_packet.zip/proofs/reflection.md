# Exact reflection structure (E864-C001 and E864-C002)

Definitions are those of PROBLEM.md. All arguments below are elementary
reproductions/developments of the user's proposed observation. No novelty claim
is made. Review is self-review, not independent or formal verification.

## E864-C001: differences and the reflected core

For every admissible finite set A of integers, every positive difference has
at most two representations as (a,b) in A^2 with a>b. If a-b=c-d>0 with
(a,b)!=(c,d), then the unordered pairs {a,d} and {b,c}, with repetition allowed,
are different and have the same sum. Indeed if the unordered pairs were equal,
either a=b and d=c, impossible, or a=c and d=b, the excluded identical case.
Consequently A has an exceptional sum S and a+d=b+c=S. This allows the
three-term progression case a=d or b=c: a diagonal representation is valid.
Thus (c,d)=(S-b,S-a), and all four endpoints belong to C=A intersect (S-A).
Three representations of one positive difference cannot occur: comparison of
(a,b) to (c,d) and (e,f) would give a+d=a+f=S and then d=f,c=e.

Conversely the reflection of (a,b) in C is (S-b,S-a), a positive-difference
representation of the same difference. It is identical precisely when a+b=S.
For an actual exceptional S put c=|C|, U=A\C, and
k=|{a in C:2a<S}|. Then c=2k+e, where e is 1 precisely if S/2 belongs to A.
Reflection is an involution on the c(c-1)/2 positive ordered difference pairs in
C. Exactly k pairs are fixed, so the number of doubled positive differences is

    R=(c(c-1)/2-k)/2.

No pair involving U can share its positive difference with ANY other pair.
The same uniqueness and disjointness hold for unordered sums involving U:
a repeated sum must equal S, but a U endpoint in such a pair would have its
complement in A, a contradiction. Such sums also cannot equal S even once.

If A has no exceptional sum, all its positive differences are unique by the
same argument; this is the ordinary Sidon case and needs no arbitrary S.
The center, if present, belongs to C, not U. The inequalities S>=2 and S<=2N
are automatic for sums from A subset [1,N], but no location near N is assumed.

## E864-C002: the exact symmetric criterion

For every integer S>=2 and every B subset [1,floor((S-1)/2)], put
A0=B union (S-B). Then A0 is admissible if and only if

1. B is Sidon for unordered sums including doubles;
2. b1+b2+b3-b4=S has no solution in B^4, with repetitions permitted.

The families of unordered sums are L=B+B, H=2S-(B+B), and
M=S+(B-B). Here every L sum is <S and every H sum is >S, so L and H are
disjoint. A repetition inside L, if it exists, also yields its reflected
repetition in H at a different integer. Hence admissibility forces B Sidon,
even when |B| is 0 or 1 and S itself need not be repeated.
For Sidon B all nonzero ordered differences are unique: equality of two positive
differences gives two equal unordered sums, forcing the pairs identical; negative
differences follow by reversing. Thus M has distinct representations away from S,
and the representations at S are exactly (b,S-b), one per b in B. Empty and
singleton B are allowed. Their exceptional multiplicity is respectively 0 or 1.

A collision between L and M reads b1+b2=S+b4-b3, exactly condition 2's forbidden
equation. Such a collision occurs below S. Reflection creates a second collision
between H and M above S. Thus any such collision prevents admissibility even
when |B|<=1; conversely in their absence no further collision is possible.
The L and M pairs are different because M uses one element from S-B, whereas
L uses two from B; the two parts are disjoint. Reflection also proves that the
H/M intersection is absent exactly when the L/M intersection is absent.
This proves both directions, including multiplicities and every intersection.

If S is even and t=S/2, the augmented A=A0 union {t} is admissible if and only
if conditions 1 and 2 hold and

3. b1+b2-b3=t has no solution in B^3, repetitions permitted.

Necessity of 1 and 2 follows by inheritance to A0. A forbidden triple produces
the collision b1+b2=t+b3<S and its reflected collision >S. For sufficiency,
the new low sums t+B are individually distinct. Their intersections with L
are exactly condition 3. An intersection t+b=S+x-y with M gives b+y-x=t,
also condition 3. The reflected high sums t+(S-B) are handled by reflection;
low/high sums cannot intersect. Finally t+t=S can only enlarge the allowed
exceptional fiber. The conclusion includes B empty and singleton.

Ambient interval requirement: for nonempty B, A0 subset [1,N] holds exactly
when max(B)<=N and S-min(B)<=N (positivity already follows). The second
inequality implies the first because S-min(B)>max(B). For the central variant
also require t<=N; it is automatic for nonempty B if A0 fits. For B empty,
A0 is empty for every positive N, while the central variant fits iff 1<=t<=N.

These are characterizations of symmetric sets only. C from E864-C001 is
symmetric, but adjoining missing reflections of U need not preserve
admissibility; it is not a reduction of the original problem to symmetric sets.
