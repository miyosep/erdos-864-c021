"""Expected sums derived explicitly here, without the search program."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from verifiers.check_set import check_set


class CheckerTests(unittest.TestCase):
    def test_empty(self):
        result = check_set(1, [])
        self.assertTrue(result["admissible"])
        self.assertEqual(result["pair_count"], 0)
        self.assertEqual(result["representation_function"], {"2": 0})

    def test_singleton(self):
        result = check_set(3, [2])
        self.assertTrue(result["admissible"])
        self.assertEqual(result["representations"]["4"], [[2,2]])
        self.assertEqual(result["pair_count"], 1)

    def test_sidon(self):
        # 1+1=2, 1+2=3, 2+2=4, 1+4=5, 2+4=6, 4+4=8.
        result = check_set(4, [4,1,2])
        self.assertTrue(result["admissible"])
        self.assertEqual(result["exceptional_sums"], {})
        self.assertEqual({int(s) for s,r in result["representation_function"].items() if r}, {2,3,4,5,6,8})

    def test_one_two_three(self):
        # Six pairs: sums 2,3,4,4,5,6. The diagonal 2+2 matters.
        result = check_set(3, [1,2,3])
        self.assertEqual(result["exceptional_sums"], {"4": [[1,3],[2,2]]})
        self.assertTrue(result["admissible"])
        self.assertEqual(result["pair_count"], 6)

    def test_three_exceptional_representations(self):
        # 15 pairs: 2,3,5,7,8; 4,6,8,9; 8,10,11; 12,13; 14.
        result = check_set(7, [1,2,4,6,7])
        self.assertEqual(result["exceptional_sums"], {"8": [[1,7],[2,6],[4,4]]})
        self.assertTrue(result["admissible"])
        self.assertEqual(result["pair_count"], 15)

    def test_one_to_four(self):
        # Ten pairs: 2,3,4,5; 4,5,6; 6,7; 8.
        result = check_set(4, [1,2,3,4])
        self.assertFalse(result["admissible"])
        self.assertEqual(result["exceptional_sums"], {
            "4": [[1,3],[2,2]], "5": [[1,4],[2,3]], "6": [[2,4],[3,3]]})

    def test_invalid_inputs(self):
        for N,A in [(0,[]),(True,[]),(3,[True]),(3,[1.0]),(3,[0]),(3,[4]),(3,[1,1])]:
            with self.subTest(N=N,A=A), self.assertRaises(ValueError):
                check_set(N,A)


if __name__ == "__main__":
    unittest.main()
