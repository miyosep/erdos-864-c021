"""Original bounded pair-sum/difference enumerator; no checker decision imported."""
from collections import Counter


class CapReached(Exception):
    pass


class Budget:
    def __init__(self,env):
        self.max_states=int(env["MATH_MAX_STATES"])
        self.max_periods=int(env["MATH_MAX_PERIOD_ENUMERATION"])
        self.max_workers=int(env["MATH_MAX_PARALLEL_WORKERS"])
        assert self.max_workers>=1
        self.states=self.periods=0
    def tick(self,n=1):
        if self.states+n>self.max_states:
            raise CapReached("state cap reached before expansion")
        self.states+=n
    def period(self,n):
        if self.periods+n>self.max_periods:
            raise CapReached("period cap reached before expansion")
        self.periods+=n
    def report(self):
        return {"states":self.states,"periods":self.periods,"workers":1,
                "caps":{"states":self.max_states,"periods":self.max_periods,"workers":self.max_workers}}


def forbidden_support(B,p,budget,translation_mod=0):
    """Complete ordered counts, using unordered first pair with weights 1/2.

    Here '1/2' means weight 1 for a diagonal pair, weight 2 otherwise.
    It does not mean a fractional weight. Each ordered quadruple is covered once.
    """
    assert len(B)==p and len(set(B))==p
    B=sorted(B)
    m,v=B[0],B[-1]
    D=v-m
    M=p*p-1
    counts=Counter()
    witnesses={}
    for i,a in enumerate(B):
        for b in B[i:]:
            weight=1 if a==b else 2
            for c in B:
                for d in B:
                    budget.tick()
                    h=a+b+c-d
                    counts[h]+=weight
                    witnesses.setdefault(h,[a,b,c,d])
    assert sum(counts.values())==p**4
    assert min(counts)==3*m-v and max(counts)==3*v-m
    for h,w in witnesses.items():
        budget.tick()
        assert w[0]+w[1]+w[2]-w[3]==h and all(x in B for x in w)
    first=2*v+1
    upper=3*v-m+1
    missing=[]
    for S in range(first,upper+1):
        budget.tick()
        if not counts[S]:
            missing.append(S)
    assert missing and missing[-1]==upper
    S=missing[0]
    assert all(counts[h]>0 for h in range(first,S))
    # Independently verify the modular relative-difference pattern.
    diffs=Counter()
    pairs=Counter()
    for a in B:
        for b in B:
            budget.tick()
            diffs[(a-b)%M]+=1
            pairs[(a+b)%M]+=1
    modular=[0]*M
    carry_layers={}
    for h,n in counts.items():
        budget.tick()
        r=h%M
        carry=(h-r)//M
        modular[r]+=n
        carry_layers.setdefault(str(r),{})[str(carry)]=n
    for r in range(M):
        budget.tick()
        expected_diff=p if r==0 else (0 if r%(p+1)==0 else 1)
        assert diffs[r]==expected_diff,(p,r,diffs[r],expected_diff)
        expected=p*p-p+int((r-2*translation_mod)%(p+1)!=0)+p*pairs[r]
        assert modular[r]==expected and modular[r]>0,(p,r,modular[r],expected)
    # Exact endpoint-hole parameter d, with -1 sentinel for no nonnegative hole.
    Z={3*v-m-h for h in counts}
    deficits=[]
    for z in range(D):
        budget.tick()
        if z not in Z:
            deficits.append(z)
    deficit=max(deficits,default=-1)
    N=S-2*m+1
    assert N==3*D+1-deficit
    edge_gap=min(B[1]-B[0],B[-1]-B[-2])
    if edge_gap>=2:
        assert deficit>=edge_gap-1
    shift=1-m
    A=sorted([b+shift for b in B]+[S-b+shift for b in B])
    assert len(A)==2*p and len(set(A))==2*p and min(A)==1 and max(A)==N
    return {"p":p,"M":M,"B":B,"min_B":m,"max_B":v,"span":D,
            "S":S,"N":N,"A":A,"size":2*p,"reflection_sum_after_translation":N+1,
            "full_integer_range":[3*m-v,3*v-m],"S_scan_range":[first,upper],
            "all_missing_S_in_scan":missing,
            "prefix_witnesses":[[h,witnesses[h]] for h in range(first,S)],
            "support":[[h,counts[h],witnesses[h]] for h in sorted(counts)],
            "ordered_quadruples":p**4,"modular_counts":modular,
            "carry_layers":carry_layers,"endpoint_deficit":deficit,
            "endpoint_missing_deficits":deficits,"edge_gap":edge_gap,
            "N_over_p_squared":{"numerator":N,"denominator":p*p},
            "normalized_cardinality":2*p/(N**0.5)}
