"""Original finite-field construction; verifier is imported only after generation.

Every multiplication and finite candidate is charged to the state counter.
Group period enumeration is separately charged before each power table.
"""
import json
import math
import os
import sys
from fractions import Fraction
from itertools import combinations
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from verifiers.check_set import check_set


def main():
    cfg=json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    cap=int(os.environ["MATH_MAX_STATES"])
    pcap=int(os.environ["MATH_MAX_PERIOD_ENUMERATION"])
    wcap=int(os.environ["MATH_MAX_PARALLEL_WORKERS"])
    assert wcap>=1
    states=periods=0
    def tick(n=1):
        nonlocal states
        if states+n>cap:
            raise RuntimeError("state cap reached")
        states+=n
    output=Path(os.environ["MATH_RUN_DIR"])/"outputs"
    result={"config":cfg,"caps":{"states":cap,"periods":pcap,"workers":wcap},
            "workers":1,"truncated":False,"cases":[]}
    try:
        for p in cfg["primes"]:
            tick(p)
            assert p>=2 and all(p%d for d in range(2,math.isqrt(p)+1))
            M=p*p-1
            # omega^2=alpha*omega+beta; irreducible degree two.
            if p==2:
                alpha=beta=1
            else:
                alpha=0
                squares={i*i%p for i in range(1,p)}
                beta=next(i for i in range(1,p) if i not in squares)
            def mul(x,y):
                tick()
                a,b=x
                c,d=y
                return ((a*c+beta*b*d)%p,(a*d+b*c+alpha*b*d)%p)
            def power(x,n):
                answer=(1,0)
                while n:
                    if n&1:
                        answer=mul(answer,x)
                    x=mul(x,x)
                    n//=2
                return answer
            factors=[]
            residual=M
            for d in range(2,math.isqrt(M)+1):
                tick()
                if residual%d==0:
                    factors.append(d)
                    while residual%d==0:
                        residual//=d
            if residual>1:
                factors.append(residual)
            theta=None
            for a in range(p):
                for b in range(1,p):
                    tick()
                    candidate=(a,b)
                    if all(power(candidate,M//d)!=(1,0) for d in factors):
                        theta=candidate
                        break
                if theta is not None:
                    break
            assert theta is not None and power(theta,M)==(1,0)
            if periods+M>pcap:
                raise RuntimeError("period cap reached")
            periods+=M
            value=(1,0)
            seen=set()
            B=[]
            for e in range(M):
                tick()
                assert value not in seen
                seen.add(value)
                if value[1]==theta[1]:
                    B.append(e)
                value=mul(value,theta)
            assert value==(1,0) and len(B)==p and 0 not in B
            L=p*p-2
            S=3*L+1
            N=3*L
            A=sorted(B+[S-b for b in B])
            tick(len(B)*(len(B)+1)//2+len(A)*(len(A)+1)//2+2*N)
            vb=check_set(L,B)
            va=check_set(N,A)
            assert vb["admissible"] and not vb["exceptional_sums"]
            assert va["admissible"] and va["exceptional_sums"]=={str(S):[[b,S-b] for b in B]}
            (output/f"candidate_p{p}.json").write_text(json.dumps({"B":vb,"A":va},indent=2)+"\n",encoding="utf-8")
            # h=ceil(N^(3/4)), computed by integer fourth powers.
            h=math.isqrt(N)
            while h**4<N**3:
                tick()
                h+=1
            T=0
            for b,a in combinations(A,2):
                tick()
                T+=max(0,h-(a-b))
            TB=0
            for b,a in combinations(B,2):
                tick()
                TB+=max(0,h-(a-b))
            if h<=L+1:
                assert T==2*TB
            saturation=Fraction(T,h*h)
            variance=Fraction(len(A),h)+2*saturation-Fraction(len(A)**2,N+h-1)
            assert variance>=0
            result["cases"].append({"p":p,"L":L,"S":S,"N":N,"theta":theta,
                "polynomial_alpha":alpha,"polynomial_beta":beta,"B":B,"A":A,
                "h":h,"no_short_cross_differences":h<=L+1,"T_A":T,"T_B":TB,
                "T_over_h_squared_exact":str(saturation),"T_over_h_squared":float(saturation),
                "variance_over_h_squared_exact":str(variance),"variance_over_h_squared":float(variance),
                "cardinality_constant":len(A)/math.sqrt(N)})
        result["status"]="PASS"
    except RuntimeError as error:
        result.update(status="LIMIT_REACHED",truncated=True,error=str(error))
    finally:
        result.update(states=states,periods=periods)
        (output/"capacity_family.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
        print(json.dumps(result,indent=2))
    return 0 if result.get("status")=="PASS" else 2


if __name__=="__main__":
    raise SystemExit(main())
