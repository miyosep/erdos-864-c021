"""Original canonical support experiment; reuses retained bases byte-for-byte."""
import hashlib
import json
import os
import sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from experiments.cycle3_support_common import Budget,CapReached,forbidden_support
from verifiers.check_set import check_set

cfg=json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
budget=Budget(os.environ)
out=Path(os.environ["MATH_RUN_DIR"])/"outputs"
result={"config":cfg,"cases":[],"truncated":False,"status":"RUNNING"}
try:
    data=Path(cfg["retained"]).read_bytes()
    receipt=json.loads(Path(cfg["original_receipt"]).read_text(encoding="utf-8"))
    actual_hash=hashlib.sha256(data).hexdigest()
    assert actual_hash==receipt["hashes"]["outputs"]["outputs/capacity_family.json"]
    result["retained_input_sha256"]=actual_hash
    records=json.loads(data)["cases"]
    for p in cfg["primes"]:
        original=next(c for c in records if c["p"]==p)
        row=forbidden_support(original["B"],p,budget)
        row["original_field"]={k:original[k] for k in ["theta","polynomial_alpha","polynomial_beta"]}
        N,A=row["N"],row["A"]
        budget.tick(len(A)*(len(A)+1)//2+2*N)
        check=check_set(N,A)
        assert check["admissible"]
        expected=[[b+1-row["min_B"],row["S"]-b+1-row["min_B"]] for b in row["B"]]
        assert check["exceptional_sums"]=={str(N+1):expected}
        row["independent_sum_checker"]=check
        result["cases"].append(row)
    result["status"]="PASS"
except CapReached as error:
    result.update(status="LIMIT_REACHED",truncated=True,error=str(error))
finally:
    result.update(budget.report())
    (out/"canonical_support.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({k:v for k,v in result.items() if k!="cases"},indent=2))
    print(json.dumps([{k:c[k] for k in ["p","min_B","max_B","S","N","span","endpoint_deficit","edge_gap","normalized_cardinality"]} for c in result["cases"]],indent=2))
if result["status"]!="PASS":
    raise SystemExit(2)
