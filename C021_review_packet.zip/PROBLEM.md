# Erdős #864 / JSP-000716

Starting mission supplied by the user in this chat, 2026-11-03. Work is confined
to this directory. A native Codex goal is registered; current execution status
is recorded in STATE.md. No scheduler or background job has been created.
Each logical session has at most three substantial cycles.

For a positive integer N and A subset of {1,...,N}, let r_A(s) count unordered
pairs (a,b) in A with a<=b and a+b=s, including a=b. A is admissible when at most
one s has r_A(s)>1, with no bound on that exceptional multiplicity. Empty and
Sidon sets qualify. F(N) is the largest cardinality of an admissible A.

Target: F(N)=(2/sqrt(3)+o(1))*sqrt(N), especially the upper bound: for every
epsilon>0, eventually F(N)<=(2/sqrt(3)+epsilon)*sqrt(N). An asymptotic disproof
requires a fixed positive improvement on arbitrarily large N; a finite example
does not suffice. A significant rigorously verified partial result is also a
research objective, but novelty must be assessed honestly.

The definitions agree with FormalConjectures/ErdosProblems/864.lean, lines 35-61
as accessed 2026-11-03. That file's upper and lower bound declarations both use
`sorry`; neither is a checked formal proof. Source access and original-paper
verification levels are in SOURCES.md. The user-reported lower constant is
2/sqrt(3), and the reported general upper constant is sqrt(2). We must distinguish
source reports from reproduced proofs.

Session source check completed: the retained current problem-page HTML matches
these exact definitions; original Erdős (1992) printed pp.39-40 visibly states
the same target constant and reports the lower bound. The forum's sqrt(2)
argument was read directly and a separate difference-based proof was reproduced
as E864-C006. See SOURCES.md for access times, frozen versions and limitations.

Mission obligations: exact independent checker and diagonal-sensitive regression
tests; optimized/exhaustive cross-check through N<=16 if within budget; exact
repeated-difference/reflection structure; symmetric characterization and central
element; general reflected core/unpaired decomposition; a focused mathematical
upper-bound or infinite-construction investigation; claims, reviews, experiments,
receipts and continuation state. No assumption of extremal symmetry or a special
exceptional sum is allowed. Do not claim a solution without a complete proof.
