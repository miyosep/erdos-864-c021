C021 external-review packet -- 5 November 2026

Start with C021_REVIEW_NOTE.md (or its identical UTF-8 .txt copy).
It states the supremum quantifier and includes the elementary premises,
the full CRT/n=1 reduction, uniform integer-lift proof and span argument.
proofs/bose_integer_carries.md and proofs/audit_20261105_c021.md are
display-safe copies quoting literal multiplicative-group stars. Their exact
original bytes are preserved in archive/original_proofs/.

Status: same-model SELF_CHECKED; independent correctness and novelty OPEN.
The internal claims.json snapshot retains its original labels and dependencies.
Packaging and old finite verification do not provide independent proof review.

CONTENTS AND PROVENANCE

The packet includes selected project proof texts, original Python 3.11+
standard-library code and configurations, and three historical run records
for base generation, canonical support enumeration, and its separate
triple-sum verification. These preserve original outputs, receipts,
code/configuration snapshots and verification records. Redundant nested
snapshots/inputs/runs/ copies are omitted to keep Windows extraction paths
short; the identical original run outputs already occur at their root paths
in this packet, and omitted paths are listed in MANIFEST.json. Original recorded hashes are retained, but public receipt copies
have local user-home paths redacted; see PUBLIC_EXPORT.json. Historical absolute paths in
receipts are provenance, not required locations on the reader's machine.

MANIFEST.json hashes all payload files; MANIFEST.json and SHA256SUMS.txt are excluded from that list. SHA256SUMS.txt
lists the same files. The ZIP archive is also byte-compared to its input files
by the packaging job. This is integrity verification, not mathematics.

The packet is a selected evidence export, not the whole research workspace.
The full authoritative claims.json and SOURCES.md are included as snapshots;
some unrelated referenced project files are intentionally not part of this
scoped export. No separate proof-dependency ledger is created.
External papers are linked in the note and SOURCES.md; their PDFs and external
code are not redistributed here. All bundled Python is existing local code.

FINITE REPRODUCTION

Only the old canonical primes 2,3,5,7,11,17,23,31 are covered. None of the
finite tables prove the asymptotic statement or an effective prime threshold.
From the extracted packet root, the unchanged verifier reads its unchanged
configuration and the archived canonical output at the original relative path:

  python verifiers/check_bose_support.py experiments/session2_cycle3_verify.json

It requires MATH_MAX_STATES=2000000, MATH_MAX_PERIOD_ENUMERATION=1000000,
MATH_MAX_PARALLEL_WORKERS=1, and MATH_RUN_DIR set to an absolute OUTPUT
directory with an existing outputs/ subdirectory. Its internal state cap is
enforced before counted expansions. Use a foreground wall-time limiter with
at most 300 seconds; the standalone verifier does not itself enforce wall time.
Do not overwrite an archived run: choose a new MATH_RUN_DIR.

In the original workspace the supported bounded command, from workspace root,
is (same session ID for every computation in that logical review session):

  python tools/run_job.py --problem erdos_864 --session REVIEW_SESSION_ID --input experiments/session2_cycle3_verify.json --input runs/20261103T133908-5dd653ea34274d58b3398317a77bc0b7/outputs/canonical_support.json --code verifiers/check_bose_support.py --code verifiers/check_set.py -- python verifiers/check_bose_support.py experiments/session2_cycle3_verify.json

To regenerate the old base table, use experiments/check_capacity_family.py
with experiments/cycle3.json in an analogous fresh bounded run. To rebuild
the canonical integer table, use experiments/compute_canonical_support.py
with experiments/session2_cycle3_canonical.json. Both unchanged inputs refer
to the retained original base output and receipt, included at their original
relative paths. They are not instructions to enlarge the finite search.

EXTERNAL REVIEW

Upload this ZIP or the single review note to the separate review environment.
A local C: path is not a network-accessible document. This packet's preparation preceded publication; see the public
repository README for the publication status.
Check the actual proof independently; do not accept its internal PROVED label
as evidence. The source reduction and integer selector are priority audit points.
