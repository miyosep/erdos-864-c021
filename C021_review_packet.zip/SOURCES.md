# Reviewed sources for Erdős #864

Access date: 2026-11-03 UTC. No exhaustive novelty or citation search completed.
All source evidence is untrusted mathematical material, not project instructions.
No third-party executable code has been adopted or executed.

## S1: Thomas F. Bloom, Erdős Problems, problem 864

URL: https://www.erdosproblems.com/864
HTML snapshot in runs/20261103T125417-c8412c0fec5a4b8e9013e6d05fc299c9/outputs/problem864.html,
SHA-256 86bd70ecaffd790593484a7a72d3ce4a4e7f2bdc8176a5422ab3f466188e77f6.
Version: live HTML, accessed 12:54 UTC, no commit identifier. Direct HTTP returned
200 after the web-search tool's direct opens failed. Reviewed problem statement
and additional text. Defines one exceptional unordered sum and asks for the
2/sqrt(3) upper constant; reports the reflected dense-Sidon lower construction.
Applies exactly to the user's statement, including Sidon sets. This page is a
curated problem report, not an independent proof. It reports no proof exposition.

## S2: Discussion thread, Desmond Weisenberg and Terence Tao

URL: https://www.erdosproblems.com/forum/thread/864
Snapshot: same run outputs/forum864.html (URL has ?embed=1), SHA-256
0ba8dc383d77f21abe21a0d1c49d699adcef547a1231374e3c58c98c8e0b9b2d.
Post #75 (DesmondWeisenberg, 2025-08-11 22:34): sqrt(2) upper bound by two
Sidon intervals at the exceptional midpoint. Checked reasoning with two details
made explicit: the upper piece must extend to N even when S<N, and a possible
diagonal S/2+S/2 cannot collide with a second pair entirely below S/2. Uniform
ordinary Sidon bounds then apply to both interval lengths. The page warns that
comments are not verified. Our separate proof E864-C006 uses differences instead.
Post #1398 (TerenceTao, 2025-10-23 15:51) links small extremizers through 69.
No other mathematical posts appear in this retained current snapshot.

## S3: David Spencer, GitHub issue 143 (2025-10-22, closed 2025-11-03)

URL: https://github.com/teorth/erdosproblems/issues/143
Read via web retrieval 2026-11-03; mutable issue, no local snapshot/commit frozen.
Reports 69 exact terms, agreement of two programs through 40, and reflected
witnesses at jumps. Author explicitly did not enumerate all optimal sets and
did not assert symmetry is mandatory. Closure concerns OEIS approval, not the
asymptotic conjecture. External search code was not imported or run; its license
was therefore not used as authorization to incorporate it.

## S4: OEIS A389182, David Spencer, extension by Alper Ferudun

URL: https://oeis.org/A389182
Table: https://oeis.org/A389182/b389182.txt
Entry reviewed: definition, examples, extension dated 2026-07-12, link to 1..100.
Current table retained in source run outputs/oeis_b389182.txt, SHA-256
ab8b01d668e0efd0b9f4ffc61a787e1db251f18ca7e3072a3003374b8a2148b2.
The 69-term report is historically correct but no longer the longest published
table. No local verification of the 17..100 upper bounds; only 1..16 independently
enumerated in this session. All values used here are finite data, not asymptotics.
No external code adopted. This record is provenance, not proof of larger maxima.

## S5: Formal Conjectures, ErdosProblems/864.lean

URL: https://github.com/google-deepmind/formal-conjectures/blob/main/FormalConjectures/ErdosProblems/864.lean
Frozen file commit: 7db2ea3b91bfbd0ab620215163e6c488bbb916d5 (latest path commit
returned by GitHub API on access). Retained as source-run outputs/864.lean;
SHA-256 daf645019ab16c5d48d2c699dac2583ad21755c010062ba4547c667149818c74.
Reviewed definitions and both asymptotic declarations. Both declarations end in
`sorry`; the lower bound's category annotation does not make it a completed
formal proof. Small Sidon/three-element/four-element test theorems have visible
proof terms, but no Lean compiler, library axioms, or build was checked here.
License: Apache-2.0 header retained; snapshot is source evidence only, not code
executed/adopted in a verifier. Its statement matches the user's quantifiers.

## S6: Paul Erdős, Some of my forgotten problems in number theory (1992)

Hardy-Ramanujan Journal 15, 34-50. DOI 10.46298/hrj.1992.125.
Journal: https://hrj.episciences.org/125 ; PDF: https://hrj.episciences.org/125/pdf
Version: journal-hosted scan, HAL hal-01108666v1 per journal metadata.
PDF retained in source-run outputs/erdos_1992.pdf; SHA-256
51faf4558eacab8e188efbcb028937f75dcb10d37865ab71ef1522df33361c72.
Read rendered printed pages 39-40 (PDF pages 6-7), not just garbled OCR. End of
p.39 states one repeated sum is allowed and the lower constant 2/sqrt(3) is
possible. Start of p.40 proposes that constant as asymptotic optimum. Does not
give a proof of the lower construction in this passage. The adjacent difference
variant is separate. Dense ordinary Sidon asymptotics also reported on p.37
(text checked, not all displayed estimates visually checked). The journal
identifies a HAL authorization license; original PDF retained for research review,
not republished. No content executed.

## S7: Erdős and Freud, On sums of a Sidon-sequence (1991)

Journal of Number Theory 38, 196-205. DOI 10.1016/0022-314X(91)90083-N.
Publisher URL: https://www.sciencedirect.com/science/article/pii/0022314X9190083N
Bibliography confirmed via S1/S5 and EMIS citation 731.11008. Full original NOT
reviewed: publisher redirect failed with the web tool. Attribution/construction
is checked at the source-report level S1/S6, with our elementary admissibility
proof in reflection.md. Do not describe this session as a full reproduction of
the original 1991 paper or all-N dense-Sidon construction.

## Literature scope and follow-up

Searched one-exception sums, near-Sidon weights/reflection and later upper bounds.
Other automated reports appeared; their claims were not used as premises.
Pikhurko's broader quasi-Sidon bounds address a different class and do not
improve sqrt(2) here. No primary newer solution verified. This limited search
does not establish novelty or a complete current-literature frontier.

Source acquisition/Poppler render command and hashes are in source_receipt.json
and the enclosing real runner receipt. Poppler version was not declared in that
receipt; a supplemental local provenance check will record it without rewriting
the original receipt. Snapshots are unmodified source evidence.

Supplement completed: run 20261103T130416-9c8075d9322e488f8746f0a72fe33944 records
Poppler 26.07.0 and its executable hash and verifies 57 original output hashes.

## S8: Melvyn B. Nathanson, The Bose-Chowla argument for Sidon sets (2022)

Journal of Number Theory 238, 133-146; DOI 10.1016/j.jnt.2021.08.005.
Author-hosted publisher PDF: https://www.theoryofnumbers.com/melnathanson/pdfs/nath2022-198.pdf
Version: final journal article, received 2021-04-29, accepted 2021-08-16.
Accessed 2026-11-03T13:04 UTC; SHA-256
bda10d9ffed2b89690b1960434e385ad19990a99add44868faf54deb5f0b5ff2.
Retained in supplemental run outputs/nathanson_2022.pdf. Visually read complete
printed pp.136-137, Theorems 1-2 and proof. Theorem 1 gives q elements of
[1,q^h-2] Sidon modulo q^h-1 for prime-power q and h>=2. Our h=2, q=p
argument is a reproduction with the finite-field existence details supplied.
Theorem 3's all-N dense-Sidon lower result on p.138 was read as extracted text;
it invokes an external prime-gap result not independently verified here.
The PDF is copyright Elsevier, retained for private research review; no text or
code is imported into verifiers. No claim that Bose-Chowla is novel to this work.

## S9: Ortega and Prendiville, Extremal Sidon Sets are Fourier Uniform (2023)

Full title: Extremal Sidon Sets are Fourier Uniform, with Applications to
Partition Regularity. Journal de théorie des nombres de Bordeaux 35(1), 115-134.
DOI 10.5802/jtnb.1239. Published 2023-05-04; accepted 2022-07-30.
Published PDF: https://www.numdam.org/item/10.5802/jtnb.1239.pdf
ArXiv reference: https://arxiv.org/abs/2110.13447 (v1 is not the frozen version).
Snapshot: runs/20261103T131859-5e870597530e4880ac12d8f264ba1d38/outputs/ortega_prendiville_2023.pdf,
accessed 2026-11-03T13:19 UTC, SHA-256
8ca74a3ccf8ae55bbdb496df0c9b32bf263bd5a7e56217a3e78b08e22eca0040.
Visually reviewed printed pp.116,118,128. Theorem 6.3 bounds Fourier discrepancy
by O(L^(1/2)(|1-b/sqrt(L)|+L^(-1/4))^(1/2)); it is not a four-variable counting
theorem. Theorem 1.15 requires at least five variables and homogeneous equations.
Dense Sidon equidistribution is explicitly attributed to Erdős-Freud. Source
statements and local proof sketch reviewed, not the full article's proof.
License: CC BY-ND 4.0 France, original PDF retained unchanged; no code adopted.
Our C008 and C010 derivations are self-contained reproductions/developments;
no new result follows merely from the cited source or failed literature searches.

## S10: Javier Cilleruelo, Combinatorial problems in finite fields and Sidon sets

Primary preprint: https://arxiv.org/pdf/1003.3576v2 ; version 2, 2011-02-18.
Retained in runs/20261103T133442-d7f9be40193744ea97a760521c7899a0/outputs/cilleruelo_2010_v2.pdf,
accessed 2026-11-03T13:34 UTC; SHA-256
4377a625e3c44c8a52da65a99bd224e35117a921543cea49a01e18ec8b5ad544.
Printed pages 1-5 visually read (separate render run
20261103T133528-4719d403cdfc4acab09778af17d31a15). Section 2, identities
(2.1)-(2.3), Theorem 2.1 and finite-field Examples 1-3 concern representation
counts/Sidon sets in finite groups. This checks overlap with the counting
framework, but supplies no carry-resolved theorem for integer 3B-B here.
Our exact Bose relative-difference/convolution argument is self-contained;
the underlying construction was already checked in S8. No novelty claim from
this limited review. Retained unchanged as research source evidence; no source
code imported or executed. arXiv redistribution-license metadata not audited.

Attempted additional primary source: Martin-O'Bryant, arXiv math/0408081v1,
https://arxiv.org/pdf/math/0408081v1 returned HTTP 500 in the same receipt.
No contents reviewed or premises adopted from that failed retrieval. Public
search service calls also returned HTTP 503. These failures do not establish
novelty. A direct pdftotext attempt failed because that executable is unavailable;
the retained Cilleruelo pages were instead rendered with declared Poppler
26.07.0 and visually reviewed before numerical support jobs began.

## Signed-correlation review source status, 2026-11-03

S9 and its checked hypotheses were revisited: a Sidon B subset [M] with
b/sqrt(M)->1 meets the reported Fourier-uniformity premise Delta=o(b).
This supplies a preliminary hypothesis, not a signed phase-balance inequality.
The five-variable theorem is still not a four-variable positivity theorem.
Our C017 implication and C019 phase bound are proved self-contained; no source
theorem is used to assume the missing negative-correlation bound.

A primary-overlap search for conjugate-function fourth-moment inequalities and
Sidon mixed terms returned HTTP 503. No new primary text was retrieved, and no
novelty follows from that failure. The elementary analytic fourth-moment
argument has not received a novelty audit. No external advice or imported code
was treated as an established proof. Review outcome is HOLD, not a new theorem
improving the asymptotic frontier.

## S11. Function-field Dirichlet bound used in the carry argument

J. P. Keating and Z. Rudnick, *The Variance of the Number of Prime Polynomials
in Short Intervals and in Residue Classes*, author-hosted IMRN final PDF,
printed pp. 12–13, §3.4, equations (3.26), (3.29)–(3.33).
https://www.math.tau.ac.il/~rudnick/papers/KeatingRudnickIMRNfinal.pdf
Read the displayed derivation directly on 2026-11-03 UTC. At n=1, (3.33)
bounds the sum over monic linear polynomials of any nonprincipal Dirichlet
character mod Q by (deg Q-1)sqrt(q). This uses the function-field Riemann
hypothesis. Our squarefree Q has degree 2 or 5; primitivity is not needed
for this bound. The source does not state our integer-carry conclusion.
No imported code. Literature novelty of that application has not been verified.

For comparison only, the live *Erdős Problem a Day* working report, §7,
https://erdosproblemaday.com/report/864 (read 2026-11-03 UTC), sets out the
general symmetric avoided-sum question. It is a secondary project report;
none of its computer searches or mathematical claims is a premise here.

## S11 recheck for middle triple fibres, session 05

Accessed 2026-11-03 UTC: https://arxiv.org/pdf/1204.0708v3 (2012-07-17),
Keating--Rudnick, printed pp.9--10, section 3.4, (3.26)--(3.33).
The author-hosted final PDF timed out on this access; the primary arXiv
version was read directly. Equation (3.33) bounds a NONPRINCIPAL Dirichlet
character sum over monic polynomials with von Mangoldt weight. At degree one
all weights are one, giving (deg Q-1)sqrt(p). Primitivity is not required;
the later section imposes it only for a cleaner Frobenius formulation.
C025 uses squarefree moduli of degrees 5,4,3, checks nonprincipality on
independent residue fields, and treats the merged case at fixed frequencies.
The external input is the function-field Riemann hypothesis, not an unproved
number-field hypothesis. The source does not assert our integer-tier or
asymmetric-attachment conclusion. Proof status here is SELF_CHECKED only.
No source code imported; no new numerical/source-fetch job was needed for
this browser-based reading. No novelty audit of the application completed.

S8 was also rechecked at
https://www.theoryofnumbers.com/melnathanson/pdfs/nath2022-198.pdf ,
published Theorem 1, printed pp.136--137. Its h=2 construction has p logs
in [1,p^2-2] and is Sidon modulo p^2-1, with repeated coordinates allowed.
This is the exact complete standard family used here, for any primitive theta.

## S12: prior modular triple-counting overlap

D. F. Daza, C. A. Trujillo, F. A. Benavides, *Sidon sets and C4-saturated
graphs*, https://arxiv.org/pdf/1810.05262v6 , version 6, 2019-03-18.
Accessed/read 2026-11-03 UTC: Construction 2.1 and Lemma 2.1 (printed p.4),
Lemma 3.4(i) and its proof (printed p.11); relevant surrounding definitions.
They give the degree-two relative differences and p-1 to p ordered
nonbase modular triple witnesses. This overlaps the elementary counting
part of C024; treat that content as reproduction. Our exact coset indicator
and integer-fibre argument are proved locally. This source is checked for
overlap, not used as a premise for an integer carry estimate. No code
imported, no claim that the rest of its graph results were verified.
Limited searches for Bose--Chowla triple saturation did not establish
novelty of C025 or C026. Their novelty remains NOT_CHECKED.

## S11 adversarial recheck, e864_20261103_07_audit

2026-11-03 UTC: root and same-model audit agents directly reread
https://arxiv.org/pdf/1204.0708v3 , sections 3.2, 3.4, (3.26)--(3.33),
and section 5's explicit imprimitive application. The author-hosted final
PDF timed out for root; the arXiv primary version was accessible.
The degree-one specialization applies to all nonprincipal characters,
not only primitive ones; its von Mangoldt weights are one. Applicability
to C025 was checked after explicitly distinguishing parameter roots from
Dirichlet-modulus roots; see proofs/audit_20261103_07_c025_algebra.md.
No new source theorem, imported code, numerical experiment or novelty claim.

## Endpoint-associated hole cycle, e864_20261103_08

2026-11-03 UTC: revisited primary S9,
https://www.numdam.org/item/10.5802/jtnb.1239.pdf , introductory extremal
Sidon distribution/Fourier statements and the stated five-variable scope.
No theorem there was adopted to estimate the selected realizing-endpoint
correlation. The range/counting proof uses the retained self-contained
C008 argument; no new uniformity hypothesis was assumed.
The live #864 page returned 403 in this access; the existing source-checked
statement in PROBLEM.md was retained. Search reports were not used as premises.

S13 (overlap only): T. Tao, author exposition *On the diameter and
distribution of Sidon sets*, 2026-10-28,
https://terrytao.wordpress.com/2026/10/28/on-the-diameter-and-distribution-of-sidon-sets/ .
Read introductory weighted-convolution displays on 2026-11-03 UTC.
They concern ordinary Sidon diameter/distribution bounds, not the present
endpoint-selected hole correlation. No result from that paper/exposition
is a proof dependency here; the full linked preprint was not audited.
The convolution and macroscopic distribution ingredients are standard/
reproduced. Limited searching does not establish novelty of the elementary
packing obstruction or explicit slot relaxation; novelty remains NOT_CHECKED.

## Exact rectangles, e864_20261104_01

Client date 2026-11-04, source access 2026-11-03 UTC: revisited S13's
author-hosted introduction at the existing URL, and a limited primary-source
search for additive sum/difference convolution identities. No new theorem
or estimate was adopted. The anchored reconstruction and all-label
convolution regrouping are elementary reproductions, proved locally.
The quantitative C033 repair bound is self-contained; its literature
novelty remains NOT_CHECKED. This limited search does not establish novelty
or impossibility of other nonfactorizing endpoint methods. No imported code.

## Fixed-height deletion certificate, e864_20261104_03

Client date 2026-11-04; accessed 2026-11-03 UTC: primary S11,
https://arxiv.org/pdf/1204.0708v3 , section 3.4 equation (3.33) and its
section-5 imprimitive application were reread directly. The new weighted
positive-link estimates use the audited C025 proof with its explicit
modulus-sign amendment; the global weighted witness count uses C021.
No conditional fixed-negative theorem is inferred from either source.

Limited overlap searches for Bose--Chowla deletion hypergraphs and fixed
triple-sum links did not supply the required uniform fixed-negative curve
estimate. No result from search snippets was adopted, and no novelty is
inferred. C036--C038's elementary matching/moment/charge arguments and
the fractional certificate are proved locally; literature novelty remains
NOT_CHECKED. C039 is explicitly OPEN; no general character-sum theorem
on its different fibre was claimed applicable without hypothesis checks.
No external code, paid resource, or new numerical computation.

## S13: Artin-character curve estimate, session e864_20261104_04

Farashahi, Fouque, Shparlinski, Tibouchi, Voloch, *Indifferentiable
Deterministic Hashing to Elliptic and Hyperelliptic Curves*, author-hosted
18-page PDF: https://www.normalesup.org/~tibouchi/papers/welldistributed.pdf
Accessed directly 2026-11-03 UTC. Section 4, PDF p.8, Lemma 1 and its
curve convention. Used only for the classical Artin bound in terms of
genus/conductor; our application imposes geometric nontriviality, checked
by nontrivial inertia. The explicit Lang cover and six-puncture tame
conductor are derived locally in bose_fixed_negative_curve.md. No
genus-zero S11 substitution, imported code or novelty claim.

## S14: zero-mode curve bound, same session

Elkies, Howe, Kresch, Poonen, Wetherell, Zieve, *Curves of every genus
with many points, II: asymptotically good families*, arXiv:math/0208060v1,
8 Aug 2002: https://arxiv.org/pdf/math/0208060v1 . Read introduction
PDF p.1 (curve convention and Weil upper bound) and Lemma 2.1 proof,
PDF pp.3--4 (both Weil bounds). Applied to our smooth, geometrically
irreducible projective genus-one model. No construction theorem from
that paper is used. Van der Geer's arXiv:1409.6090v1 survey, p.2, was
also checked for the displayed absolute-error formulation, but is not
an additional premise. Weil's 1949 diagonal-equation paper was opened
but not used as a statement of a general curve estimate. DOI access to
the van der Geer journal page failed; no inaccessible text is relied on.

Scope amendment to the historical session-03 note above: C039 was OPEN
then; session 04 now supplies the separate curve argument. Classical
curve/character ingredients are reproduction. The fixed-negative
application and matching are new to this project, novelty NOT_CHECKED;
same-model review only. This limited source check is no novelty audit.

## Premise-use record, session e864_20261104_05

Read the recorded scopes/reviews and actual relevant arguments for
C008, C021, C036, C039 and C041--C043. No new external theorem or code
was imported. The new survivor-minimum argument uses affine measure
transport and disjoint cover costs; inherited S11/S13/S14 applications
retain their recorded SELF_CHECKED status. This cycle did not perform
a new source or novelty audit. New-to-project C044/C045 have novelty
NOT_CHECKED, and no assertion of literature priority is made.

## Premise-use record, session e864_20261104_06

Read C001/C005/C007/C009/C018/C019/C028/C029 and their actual relevant
proofs, plus the exact-rectangle/masked-correlation obstruction C031--C035
and the session-02 gate. The translate midpoint observation is supplied
by the user and reproduced from C001. Gram positivity, Parseval and the
Schur-complement calculation are derived locally; no new external
theorem, source code, paid resource or literature-novelty assertion was
adopted. C047 is a new-to-project scoped moment relaxation with novelty
NOT_CHECKED. C048 remains an unproved asymptotic candidate. All actual
review in this session is SELF_CHECKED, not independent verification.

## Premise-use record, session e864_20261104_07

Read C001, C005--C007, C046--C048 and their relevant arguments; checked
the earlier endpoint-packing and rectangle/masked-association failures.
C049 reproduces the user's proposed common-endpoint rejection. C050
uses elementary counting and the recorded finite translate inequalities.
C051 reuses ONLY the classical dense Sidon family and elementary
translate identity already proved in C007 (S8 input); no new external
theorem, field-character estimate, code or construction search was
imported. Its reflected set is expressly nonadmissible and is used
as a local-method obstruction. No literature-novelty audit was made;
new-to-project auxiliary claims retain NOT_CHECKED/SELF_CHECKED labels.

## Premise-use record, session e864_20261104_08

Read the current C001/C005--C007/C035/C046--C051 records and their
relevant arguments, including common_short_endpoints.md and the
exact-rectangle obstruction before selecting the count. C002/C008/C009
were consulted for center removal, dense Sidon distribution and the
existing marginal-capacity comparison. No new external theorem, code,
character estimate or literature-priority assertion was adopted.
C052/C053 are same-model auxiliary derivations, novelty NOT_CHECKED;
no independent audit or numerical experiment is represented as performed.

## S9/S11 source recheck: C021 audit, 2026-11-05 Asia/Shanghai

Session e864_20261105_01_audit, same-model SELF_CHECKED only. Accessed
2026-11-04 UTC. S11: Keating and Rudnick, arXiv:1204.0708v3,
https://arxiv.org/pdf/1204.0708v3 (version dated 2012-07-17), printed
pp.9--10, section 3.4, (3.31)--(3.33); visually checked those two
rendered pages. The n=1 nonprincipal-character estimate does not assume
primitivity; the primitive convention starts in section 3.5. This is
the actual external theorem used by C021, with degree-2 and degree-5
local moduli and CRT nonprincipality justified in the audit. No source
theorem asserting the integer-carry conclusion was identified here.

S9: Ortega and Prendiville, published 2023 version,
https://www.numdam.org/item/10.5802/jtnb.1239.pdf . Visually checked
printed pp.118--119 (Theorem 1.15 and continuation) and p.128 (Theorem
6.3). The former has at least five variables and a homogeneous
partition-regular equation; the latter is a Fourier discrepancy bound.
C010 demonstrates a quantitative obstruction for its particular norm
certificate, not an impossibility of every four-variable application.

Frozen copies and all five page PNGs are under
runs/20261104T162921-374727e8e67741978bd895a04cb17117/outputs/.
The Keating--Rudnick PDF SHA-256 is
54d6ae76d339aeb3c0af867288021c863bb1b4f3d6816904aac21e496dfc52dd;
the published S9 copy is
8ca74a3ccf8ae55bbdb496df0c9b32bf263bd5a7e56217a3e78b08e22eca0040,
matching the earlier retained copy. Exact access times are in that run's
outputs/sources.json. PDFs are retained unchanged for private source
review; S9's CC BY-ND 4.0 France terms remain as recorded above. No
external source code was imported or executed. Existing local fetching
code was reused and snapshotted. Supplementary source verification
explicitly corrects the receipt's declared Poppler-version typo.

Limited overlap searches (two batches of four queries) combined
Bose--Chowla with equidistribution, 3B/3A-A, sumsets, character sums,
Weil and reflection/864. Search snippets and secondary automated
research pages were not used as mathematical premises. The GitHub
issue https://github.com/teorth/erdosproblems/issues/143 was opened as
background only: its body reports computation through N=69 and the
reflection construction; neither the optimality certificate nor its
linked code was independently audited in this cycle. No new F(69)
claim was added. Novelty remains NOT_CHECKED; unsuccessful searches
do not establish priority. Full correctness/source comparison:
proofs/audit_20261105_c021.md.

## S15: Carter--O'Bryant--Tao (2026), C021 comparison

Daniel Carter, Kevin O'Bryant, Terence Tao, *On the diameter and
distribution of Sidon sets*, arXiv:2610.36207v1, submitted 2026-10-26:
https://arxiv.org/abs/2610.36207v1 ; PDF
https://arxiv.org/pdf/2610.36207v1 . Accessed 2026-11-04 UTC in session
e864_20261105_02_packet. Visually read printed pp.6--8 and 13:
Theorems 2.3--2.5, 2.6, and the opening distribution proof. These
concern diameter, ordered positions and maximum gaps of gamma-Golomb
rulers. They do not state C021's constrained joint-coordinate or
prescribed integer-lift conclusion. No deduction of that conclusion
from the reviewed statements was established. This is a scoped
comparison, not a novelty determination or a full correctness review
of the new paper; its optimization code/certificates were not audited.

Retained unchanged PDF and four rendered pages:
runs/20261104T163945-df9e00a6aaa0499b820a538e60e9cb12/outputs/ .
SHA-256 fbfd9cf528675639d4b2a537ee50f93a37d94659413c377b22fd957d5d094b36;
accessed_at 2026-11-04T16:39:46.032247+00:00. License identified on
the arXiv HTML page: CC BY 4.0. No external code imported or executed;
the external-review ZIP links the paper and does not redistribute it.
The HTML loses some theorem macros/numbers, so PDF numbering was used.
C021 retains SELF_CHECKED and novelty NOT_CHECKED; S15 is not added
as a proof dependency. See the standalone exported review note.
